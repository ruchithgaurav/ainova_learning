<?php
/**
 * Title: Header Home
 * Slug: blockskit-education/header-home
 * Categories: all, header
 */
?>

<!-- wp:pattern {"slug":"blockskit-education/header"} /-->
<!-- wp:pattern {"slug":"blockskit-education/hero-banner"} /-->