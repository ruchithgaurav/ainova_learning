<?php
/**
 * Title: Home
 * Slug: blockskit-education/home
 * Categories: all, home
 * Keywords: home
 */
?>
<!-- wp:group {"tagName":"main","layout":{"type":"constrained"}} -->
<main class="wp-block-group">
	<!-- wp:pattern {"slug":"blockskit-education/feature"} /-->
	<!-- wp:pattern {"slug":"blockskit-education/about"} /-->
	<!-- wp:pattern {"slug":"blockskit-education/feature-course"} /-->
	<!-- wp:pattern {"slug":"blockskit-education/category"} /-->
	<!-- wp:pattern {"slug":"blockskit-education/team"} /-->
	<!-- wp:pattern {"slug":"blockskit-education/testimonial"} /-->
	<!-- wp:pattern {"slug":"blockskit-education/latest-posts"} /-->
</main>
<!-- /wp:group -->