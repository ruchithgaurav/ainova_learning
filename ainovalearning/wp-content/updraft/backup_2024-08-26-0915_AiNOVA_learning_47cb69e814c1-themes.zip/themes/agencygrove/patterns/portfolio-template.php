<?php
/**
 * Title: Our Portfolio Page
 * Slug: agencygrove/portfolio-template
 * Categories: agencygrove
 * Keywords: portfolio
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/portfolio"} /-->
<!-- wp:pattern {"slug":"agencygrove/brands"} /-->
<!-- wp:pattern {"slug":"agencygrove/testimonials"} /-->
<!-- wp:pattern {"slug":"agencygrove/portfolio-second"} /-->
<!-- wp:pattern {"slug":"agencygrove/pricing-plan"} /-->
