<?php
/**
 * Title: About Us Page
 * Slug: agencygrove/about-template
 * Categories: agencygrove
 * Keywords: about
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/about-second"} /-->
<!-- wp:pattern {"slug":"agencygrove/services"} /-->
<!-- wp:pattern {"slug":"agencygrove/about"} /-->
<!-- wp:pattern {"slug":"agencygrove/team"} /-->
<!-- wp:pattern {"slug":"agencygrove/testimonials"} /-->
<!-- wp:pattern {"slug":"agencygrove/pricing-plan"} /-->