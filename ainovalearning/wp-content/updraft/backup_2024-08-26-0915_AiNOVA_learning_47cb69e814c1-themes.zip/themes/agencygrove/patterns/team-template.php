<?php
/**
 * Title: Our Team Page
 * Slug: agencygrove/team-template
 * Categories: agencygrove
 * Keywords: team
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/team"} /-->
<!-- wp:pattern {"slug":"agencygrove/brands"} /-->
<!-- wp:pattern {"slug":"agencygrove/about-second"} /-->
<!-- wp:pattern {"slug":"agencygrove/pricing-plan"} /-->
