<?php
/**
 * Title: Header Home
 * Slug: blockskit-base/header-home
 * Categories: all, header
 */
?>

<!-- wp:pattern {"slug":"blockskit-base/header"} /-->
<!-- wp:pattern {"slug":"blockskit-base/hero-banner"} /-->