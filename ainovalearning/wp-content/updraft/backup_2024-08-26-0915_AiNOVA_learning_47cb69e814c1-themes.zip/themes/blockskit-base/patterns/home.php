<?php
/**
 * Title: Home
 * Slug: blockskit-base/home
 * Categories: all, home
 * Keywords: home
 */
?>
<!-- wp:group {"tagName":"main","layout":{"type":"constrained"}} -->
<main class="wp-block-group">
<!-- wp:pattern {"slug":"blockskit-base/three-columns-featured"} /-->
<!-- wp:pattern {"slug":"blockskit-base/two-columns-featured"} /-->
<!-- wp:pattern {"slug":"blockskit-base/pricing"} /-->
<!-- wp:pattern {"slug":"blockskit-base/call-to-action"} /-->
<!-- wp:pattern {"slug":"blockskit-base/testimonial"} /-->
<!-- wp:pattern {"slug":"blockskit-base/post-grid"} /-->
</main>
<!-- /wp:group -->