<div class="akismet-box">
	<?php Akismet::view( 'title' ); ?>
	<?php Akismet::view( 'setup' );?>
</div>
<br/>
<div class="akismet-box">
	<?php Akismet::view( 'enter' );?>
</div>